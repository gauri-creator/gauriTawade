
	<div class="copy-right"> 
		<div class="container">
			<p>Bus Pass Management System</p>
		</div> 
	</div> 
	<!-- //footer -->   
	